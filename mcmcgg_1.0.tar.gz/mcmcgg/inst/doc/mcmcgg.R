### R code from vignette source 'mcmcgg.Rnw'

###################################################
### code chunk number 1: mcmcgg.Rnw:13-15
###################################################
library(ggplot2)
library(mcmcgg)


