abstractParam <-
function(paramNumber, chain) {
    return(chain[, paramNumber])
}
